# HW1-2 Muyuan He

###Here is location to import lib
import matplotlib.pyplot as plt
import math as m
import numpy as np
### Problem 1 ### plot will be saved

# Produce figures on log-log axes. a=b=1, x0=0.1
# exact solution is x(t)=1/(1+9e^(-t)) ; Compute δ(∆t)=|x'(t)− (x(t+∆t)-x(t))/∆t| for t=2 and for ∆t=10^(-n).
# δ(10^(-n)) == |x'(2)-(x(2+10^(-n))-x(2))/(10^(-n))|

def functx(t):
    return 1/(1+9*m.exp(-t)) #imput t and returns x(t)

def functderivx(t):
    return 9*m.exp(t)/(float(m.exp(t)+9)**2) #imput t and returns x'(t)

#def y(deltat, t):
#    return abs(functderivx(t)-(functx(t+deltat)-functx(t))/deltat)

arr_deltat = np.array([10**(-1), 10**(-2), 10**(-3), 10**(-4), 10**(-5), 10**(-6), 10**(-7)])
arr_y =np.empty(7)

x0= 0.1
y0=0
yn=0
list1 = []
list2 = []
for item in np.nditer(arr_deltat):
    r = 1+item #each item is a delta_t in the array
    yn = (item/r)*x0 # Here get y0
    #print("y0 is: ", y0)
    for j in range(int(2/item)): #how many iters to get y_n
        yn = r*yn*(1-yn)
    #after the loops now y is y_n
    y_nplus1 = r*yn*(1-yn)
    #Now we have y_n and y_n+1, need to change back to xn and xn+1
    xn = yn*(1+item)/item
    x_nplus1 = y_nplus1*(1+item)/item

    delta_delta_t = abs(functderivx(2)-(x_nplus1-xn)/item)
    #print("deltadeltat = ",delta_delta_t)
    list1.append(delta_delta_t)
    #np.append(arr_y, delta_delta_t) #This will create an array of delta(delta t), which will be transfered into log
    #log_arr_y = np.log(arr_y)
    list2 = np.log(list1)
    log_arr_deltat = np.log(arr_deltat)
    log_arr_y = np.array(list2)

# Plotting loglog graph
plt.figure(1)
plt.plot(log_arr_deltat, log_arr_y)
plt.title("problem1_python")
plt.xlabel("∆t")
plt.ylabel("δ(∆t)")
#plt.show()
plt.savefig("loglog_deltadeltat_over_deltat")


### Problem 2 part e

x1 = 1
array_2e = np.arange(start=1, stop=1600, step=1)
for item in np.nditer(array_2e):
    x1 = x1*2
    if str(x1) == "inf":
        print("int stops at 2 to the power of ", item)
    #print("2 to the power ", item)
    #print("gives", x1, "\n")      # it seems the int do not fail at any point, IF NUMPY IS USED
x1 = 1
for i in range(1500):
    x1 = x1*2
    if str(x1) == "inf":
        print("2 to the power of ", i, "returns inf for int")
x2 = 1.0
for i in range(1500):
    x2 = x2*2.0
    #print(i)
    #print(x2)
    if str(x2) == "inf":
        print("2 to the power of ", i, "returns inf")
        break
print("At 2^1023, python returns inf")
print("Problem2, part e: Python and MATLAB have the same behavior")
    
### Problem 3
a = [1, 2, 3]
b = [4, 5, 6]
v1 = a
adotb = 0
adota = 0
tot = 0
for i, j in zip(a, b):
    adotb += i*j
for i in a:
    adota += i*i

def mod(x):
    return m.sqrt(sum(i**2 for i in x))

c_list = []
for i in range(3):
    c_list.append(b[i]-a[i]*adotb/adota)

c = mod(b)/mod(c_list)
#Therefore finally
v2 = []
for j in range(3):
    v2.append(c_list[j]*c)
dotproduct = 0
for i, j in zip(v1, v2): #dot product of two orthogonal vectors should return a value really close to 0
    dotproduct += i*j # this product is 9e-15, close to 0

### Problem 4
# The other two files in the zip
### Problem 5

def logistic_calculator(r, x):
    return r*x*(1-x)

max_iter = 50
x = 0.01
r1 = 2.00
r2 = 2.99

r1_list = []
r2_list = []

for i in range(max_iter):
    x = logistic_calculator(r1, x)
    r1_list.append(x)
x = 0.01
for j in range(max_iter):
    x = logistic_calculator(r2, x)
    r2_list.append(x)
plt.figure(2)
plt.plot(r1_list)
plt.plot(r2_list)
plt.legend(["r = 2.00", "r = 2.99"])
plt.title("problem5_python")
plt.xlabel("iters")
plt.ylabel("x")
plt.savefig("logistic_r")


### Problem 6
### part a
text1 = " Problem 6 part a: know that xn+1 = r*f(xn),\n \
if x_star is a fixed point, then let xn = x_star +η; which is a close point.\n \
therefore x_star+ η_n+1 = x_n+1= f(x+star+ηn) = f(x_star) + f'(x+star)ηn + O(ηn^2)=\n \
since x_n = x_n+1 = f(xn) = x_star\n \
η_n+1 = f'(x_star)*η_n, λ = f'(x_star)\n \
therefore in general, η_n = λ^n * η0, which means if abs(λ)< 1 --> stable;\n \
elif abs(λ)>1 --> unstable; inconclusive if abs(λ) == 1;\n \
therefore λ = d/dx r*x/(1+x(2) = r(1-x^2)/(1+x^2)^2 < 1\n \
so as long as r>1, λ will be less than 1, and the map has a stable fixed pint for all r>1 \n"
print("\n")
print(text1)
print("\n")
### part b
def logistic1(r, x):
    return r*x/(1+x**2)
x_val = 0.1
logistic1_list = np.arange(1.1, 15.0, 0.05)
plt.figure(3)
for i in np.nditer(logistic1_list):
    #print(i)
    for j in range(500):
        #print(j)
        x_val = logistic1(i, x_val)
        #print(x_val)
        if j>400:
            plt.plot(i, x_val, '.', color = "black")

plt.title("problem6(b)_python")
plt.xlabel("r")
plt.ylabel("x_n+1")
plt.savefig("logistic1_x_n+1overr")

### part c
def logistic1_c(r, x):
    return r*x/(1+x**4)
x_val = 0.1
logistic1_list = np.arange(1.1, 15.0, 0.05)
plt.figure(4)
for i in np.nditer(logistic1_list):
    #print(i)
    for j in range(500):
        #print(j)
        x_val = logistic1_c(i, x_val)
        #print(x_val)
        if j>400:
            plt.plot(i, x_val, '.', color = "black")

plt.title("problem6(c)_python")
plt.xlabel("r")
plt.ylabel("x_n+1")
plt.savefig("logistic_6c")











