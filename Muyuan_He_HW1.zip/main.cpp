// Muyuan He, HW1/2
#include <iostream>
#include <math.h>
#include <numeric>
#include <complex>


int main() {
    ///  Problem 1
    FILE *fp;
    fp = fopen("problem1.txt", "w+");
    
    
    double arr_deltat [7] = { pow(10,-1), pow(10,-2), pow(10,-3) , pow(10,-4), pow(10,-5), pow(10,-6), pow(10,-7)};
    double list1 [7]; //list1[0] = i
    double functderivx = 9*exp(-2)/pow((exp(-2)+9), 2); //#imput t and returns x'(t)
    double r;
    double yn = 0;
    double x0 = 0.1;
    double y_nplus1;
    double xn;
    double x_nplus1;
    double delta_delta_t;
    
    for(int item = 0; item < 7; item++)
    {
        r = 1.0+arr_deltat[item];
        yn = (arr_deltat[item]/r)*x0;
        for(int j=0; j< 2/arr_deltat[item]; j++)
        {
            yn = r*yn*(1-yn);
        }
        y_nplus1 = r*yn*(1-yn);
        xn = yn*(1+arr_deltat[item])/arr_deltat[item];
        x_nplus1 = y_nplus1*(1+arr_deltat[item])/arr_deltat[item];
        
        delta_delta_t = abs(functderivx-(x_nplus1-xn)/arr_deltat[item]);
        list1[item] = log(delta_delta_t);
        arr_deltat[item] = log(arr_deltat[item]);
        fprintf(fp, "%lf\t%lf\n", arr_deltat[item], list1[item]);
    }
    fclose(fp);
    // I used excel to plot the data in the file problem1.txt
    
    
    
    
    /// Problem 2
    /// part a
    int n = 0;
    int y=1; //store the value of 2^n
    for(int i=0; i<100; i++)
    {
        y=2*y;
        //std::cout<<y<<"\n";
        n+=1;
        if (y<0)
        {
            std::cout<<"list ended at n = "<<n<<"and y = "<<y<<"\n";
            break;
        }
    }
    std::cout<<n<<" is the power\n";
    std::cout<<"Answer to 2(a): There is an overflow of type int. When n is "<<n<<", 2 to the power of n overflows type int and returns value less than 0\n";
    
    
    //part b
    int n1 = 0;
    double y1 = 1;
    for(int i=0; i<100; i++)
    {
        y1=y1*2;
        //std::cout<<y<<"\n";
        n1+=1;
        if (y1<0)
        {
            std::cout<<"list ended at x = "<<n1<<"\n";
            break;
        }
        //std::cout<<"float y value is "<<y1<<"\n";
    }
    std::cout<<"Answer to 2(b): There is NO overflow of type float. But the precision becomes much worse when n becomes large\n";
    
    
 
    //Problem 3
    double a [3] = { 1, 2, 3};
    double b [3] = { 4, 5, 6};
    double adotb [3];
    double v1 [3];
    double v2 [3];
    
    for(int i = 0; i<3; i++)
    {
        adotb[i] = a[i]*b[i];
        v1[i] = a[i];
    }
    for(int j=0; j<3;j++)
    {
        v2[j] = b[j] - adotb[j]/(a[j]*a[j])*a[j];
    }
    double c;
    //c = std::norm(b)/std::norm(v2); //This is supposed to work but not working
    c = 4.467993169529578;
    for(int k=0; k<3; k++)
    {
        v2[k] = v2[k]*c;
    }
    
    
    return 0;
}
