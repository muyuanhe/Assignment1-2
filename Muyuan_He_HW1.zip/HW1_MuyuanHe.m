%%% Problem 1
arr_deltat = [10^(-1), 10^(-2), 10^(-3), 10^(-4), 10^(-5), 10^(-6), 10^(-7)];
functderivx = 9.0*exp(2.0)/((exp(2.0)+9.0)^2);
array1 = [];
x0 = 0.1;


for i = 1:7
    r = 1+arr_deltat(i);
    yn = (arr_deltat(i)/r)*x0;
    for j = 1:2/arr_deltat(i)
        yn = r*yn*(1-yn);
    end
    y_nplus1 = r*yn*(1-yn);
    
    xn = yn*(1+arr_deltat(i))/arr_deltat(i);
    x_nplus1 = y_nplus1*(1+arr_deltat(i))/arr_deltat(i);
    
    delta_delta_t = abs(functderivx-(x_nplus1-xn)/arr_deltat(i));
    array1(i) = log(delta_delta_t);
    arr_deltat(i) = log(arr_deltat(i));
end

figure(1)
plot(arr_deltat,array1) 
title('')
xlabel('delta t')
ylabel('d(delta t)')



%%% Problem 2
%%% part c
x1=1;
y1=1;
%fprintf();
 for i=1:1500
     y1=y1*2;
     %disp(y1);
     %fprintf("to the power of");
     %disp(i);
 end
 fprintf("At 2^1023, MATLAB displays Inf, the max value was 8.9885e+307 \n");
 
 %%% part d
 x2 = 1.0;
 y2 = 1.0;
 for i=1:1500
     y2=y2*2.0;
     %disp(y2);
     %fprintf("to the power of");
     %disp(i);
 end
 fprintf("part d failes at the same place as part c \n");
 
 %%% Problem 3
 a = [1 2 3];
 b = [4 5 6];
 adotb = dot(a, b);
 v1 = a;
 v2 = (b-a*adotb/dot(a, a));
 %disp(v2);
 c = norm(b)/norm(v2);
 v2 = v2*c;
 disp(dot(v1, v2));
 fprintf("v1 dot v2 is close enough to 0");